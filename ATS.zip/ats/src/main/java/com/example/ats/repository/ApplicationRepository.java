package com.example.ats.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ats.model.Application;

public interface ApplicationRepository extends JpaRepository<Application, Long> {
}
