package com.example.ats.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ats.model.JobPost;

public interface JobPostRepository extends JpaRepository<JobPost, Long> {
}
