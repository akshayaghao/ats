package com.example.ats.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ats.model.Application;
import com.example.ats.repository.ApplicationRepository;

@Service
public class ApplicationService {
    @Autowired
    private ApplicationRepository applicationRepository;

    public Application submitApplication(Application application) {
        return applicationRepository.save(application);
    }
}
