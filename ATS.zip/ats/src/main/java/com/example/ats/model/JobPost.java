package com.example.ats.model;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class JobPost {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String title;
    private String location;
    private String salary;
    private String responsibilities;

    @ElementCollection
    private List<String> r1CheckQuestions;

    @ElementCollection
    private List<String> r2CheckQuestions;

    public JobPost() {
    }

    public JobPost(String title, String location, String salary, String responsibilities,
                   List<String> r1CheckQuestions, List<String> r2CheckQuestions) {
        this.title = title;
        this.location = location;
        this.salary = salary;
        this.responsibilities = responsibilities;
        this.r1CheckQuestions = r1CheckQuestions;
        this.r2CheckQuestions = r2CheckQuestions;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getSalary() {
        return salary;
    }

    public void setSalary(String salary) {
        this.salary = salary;
    }

    public String getResponsibilities() {
        return responsibilities;
    }

    public void setResponsibilities(String responsibilities) {
        this.responsibilities = responsibilities;
    }

    public List<String> getR1CheckQuestions() {
        return r1CheckQuestions;
    }

    public void setR1CheckQuestions(List<String> r1CheckQuestions) {
        this.r1CheckQuestions = r1CheckQuestions;
    }

    public List<String> getR2CheckQuestions() {
        return r2CheckQuestions;
    }

    public void setR2CheckQuestions(List<String> r2CheckQuestions) {
        this.r2CheckQuestions = r2CheckQuestions;
    }

    @Override
    public String toString() {
        return "JobPost{" +
                "id=" + id +
                ", title='" + title + '\'' +
                ", location='" + location + '\'' +
                ", salary='" + salary + '\'' +
                ", responsibilities='" + responsibilities + '\'' +
                ", r1CheckQuestions=" + r1CheckQuestions +
                ", r2CheckQuestions=" + r2CheckQuestions +
                '}';
    }
}
