package com.example.ats.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.ats.model.JobPost;
import com.example.ats.service.JobPostService;

@RestController
@RequestMapping("/api/jobposts")
public class JobPostController {
    @Autowired
    private JobPostService jobPostService;

    @PostMapping
    public ResponseEntity<JobPost> createJobPost(@RequestBody JobPost jobPost) {
        JobPost createdJobPost = jobPostService.createJobPost(jobPost);
        return ResponseEntity.ok(createdJobPost);
    }
}
