package com.example.ats.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.ats.model.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
