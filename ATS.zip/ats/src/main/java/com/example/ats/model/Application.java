package com.example.ats.model;

import java.util.List;

import jakarta.persistence.ElementCollection;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;

@Entity
public class Application {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne
    private User candidate;

    @ManyToOne
    private JobPost jobPost;

    @ElementCollection
    private List<String> r1CheckAnswers;

    private boolean shortlisted;

    public Application() {
    }

    public Application(User candidate, JobPost jobPost, List<String> r1CheckAnswers, boolean shortlisted) {
        this.candidate = candidate;
        this.jobPost = jobPost;
        this.r1CheckAnswers = r1CheckAnswers;
        this.shortlisted = shortlisted;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public User getCandidate() {
        return candidate;
    }

    public void setCandidate(User candidate) {
        this.candidate = candidate;
    }

    public JobPost getJobPost() {
        return jobPost;
    }

    public void setJobPost(JobPost jobPost) {
        this.jobPost = jobPost;
    }

    public List<String> getR1CheckAnswers() {
        return r1CheckAnswers;
    }

    public void setR1CheckAnswers(List<String> r1CheckAnswers) {
        this.r1CheckAnswers = r1CheckAnswers;
    }

    public boolean isShortlisted() {
        return shortlisted;
    }

    public void setShortlisted(boolean shortlisted) {
        this.shortlisted = shortlisted;
    }

    @Override
    public String toString() {
        return "Application{" +
                "id=" + id +
                ", candidate=" + candidate +
                ", jobPost=" + jobPost +
                ", r1CheckAnswers=" + r1CheckAnswers +
                ", shortlisted=" + shortlisted +
                '}';
    }
}
