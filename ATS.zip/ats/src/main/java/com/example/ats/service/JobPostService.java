package com.example.ats.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.ats.model.JobPost;
import com.example.ats.repository.JobPostRepository;

@Service
public class JobPostService {
    @Autowired
    private JobPostRepository jobPostRepository;

    public JobPost createJobPost(JobPost jobPost) {
        return jobPostRepository.save(jobPost);
    }
}
